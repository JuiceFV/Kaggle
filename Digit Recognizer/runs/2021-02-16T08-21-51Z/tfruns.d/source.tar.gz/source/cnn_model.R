library(keras)

ubyte_data <- FALSE
label_index <- 1

if (ubyte_data){
    # load image files
    load_image_file <- function(filename) {
      ret = list()
      f = file(filename, 'rb')
      readBin(f, 'integer', n = 1, size = 4, endian = 'big')
      n    = readBin(f, 'integer', n = 1, size = 4, endian = 'big')
      nrow = readBin(f, 'integer', n = 1, size = 4, endian = 'big')
      ncol = readBin(f, 'integer', n = 1, size = 4, endian = 'big')
      x = readBin(f, 'integer', n = n * nrow * ncol, size = 1, signed = FALSE)
      close(f)
      data.frame(matrix(x, ncol = nrow * ncol, byrow = TRUE))
    }

    # load label files
    load_label_file <- function(filename) {
      f = file(filename, 'rb')
      readBin(f, 'integer', n = 1, size = 4, endian = 'big')
      n = readBin(f, 'integer', n = 1, size = 4, endian = 'big')
      y = readBin(f, 'integer', n = n, size = 1, signed = FALSE)
      close(f)
      y
    }
    
    label_index <- 785
}

if (ubyte_data) {
    # load images
    train <- load_image_file("data/train-images.idx3-ubyte")
    train$label = as.factor(load_label_file("data/train-labels.idx1-ubyte"))

    # load labels
    test  <- load_image_file("data/t10k-images.idx3-ubyte")
    test$label  = as.factor(load_label_file("data/t10k-labels.idx1-ubyte"))
} else {
    train <- read.csv('data/train.csv')
    test <- read.csv('data/test.csv')
}

train_split_index <- createDataPartition(train$label, p=0.8, list=FALSE)
train_split <- train[train_split_index,]
test_split <- train[-train_split_index,]
X_train <- data.matrix(train_split[-label_index])/255.0
X_test <- data.matrix(test_split[-label_index])/255.0
Y_train <- to_categorical(train_split$label, 10)
Y_test <- to_categorical(test_split$label, 10)
X_train_cnn <- array_reshape(X_train, c(-1, 28, 28, 1))
X_test_cnn <- array_reshape(X_test, c(-1, 28, 28, 1))

FLAGS <- flags(
  flag_numeric("dropout", 0.5)
  flag_numeric("lambda", 0.0001)
)

model_cnn <- keras_model_sequential() %>% 
    layer_conv_2d(filters = 20, kernel_size = c(5, 5), activation = "relu", input_shape = c(28, 28, 1)) %>%
    layer_max_pooling_2d(pool_size = c(2, 2), strides=c(2,2)) %>%
    layer_conv_2d(filters = 50, kernel_size = c(5, 5), activation = "relu") %>%
    layer_max_pooling_2d(pool_size = c(2, 2), strides=c(2,2)) %>%
    layer_flatten() %>%
    layer_dropout(rate=FLAGS$dropout) %>%
    layer_dense(units = 500, activation = "relu", kernel_regularizer = regularizer_l2(l = FLAGS$lambda)) %>%
    layer_dense(units = 10, activation = "softmax", kernel_regularizer = regularizer_l2(l = FLAGS$lambda))

model_cnn %>% compile(
  loss = 'categorical_crossentropy',
  optimizer = optimizer_rmsprop(),
  metrics = c('accuracy')
)

set.seed(42)
history <- model_cnn %>% fit(
  X_train_cnn, Y_train, 
  epochs = 30, batch_size = 100, 
  validation_data=list(X_test_cnn, Y_test),
  verbose = 2
)

plot(history)

evaluate(model_cnn, X_test_cnn, Y_test)